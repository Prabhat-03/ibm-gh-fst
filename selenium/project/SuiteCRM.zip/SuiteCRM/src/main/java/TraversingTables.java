import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

public class TraversingTables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		Actions builder = new Actions(driver);
		
		driver.get("https://demo.suiteondemand.com/");
				
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		WebElement sales = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='grouptab_0']")));
		//sales.click();
		builder.moveToElement(sales).click().pause(2000).build().perform();
		
		
		WebElement account = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id ='moduleTab_6_Accounts']")));
		builder.moveToElement(account).click().build().perform();
		
		List<WebElement> oddRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[@class='oddListRowS1']/td[@type='name']//a")));
		
		System.out.println("Odd Rows Size : " + oddRows.size() + " The first Five Names are: ");
		
//		for(WebElement o: oddRows) {
//			System.out.println(o.getText());
//		}
		

		for (int i = 0; i < oddRows.size() && i < 5; i++) {
			System.out.println(oddRows.get(i).getText());
		}
	
		driver.close();
	}

}
