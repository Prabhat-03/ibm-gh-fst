import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class HeaderImageURL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://demo.suiteondemand.com/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement img = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='SuiteCRM']")));
		System.out.println(img.getDomAttribute("src"));
		
		driver.quit();
	}

}
