
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class LeadPhoneNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		Actions builder = new Actions(driver);
		
		driver.get("https://demo.suiteondemand.com/");
				
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		WebElement sales = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='grouptab_0']")));
		//sales.click();
//		System.out.println("entered sales");
		builder.moveToElement(sales).click().pause(2000).build().perform();
		
		WebElement leads = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='moduleTab_6_Leads']")));
	
		builder.moveToElement(leads).click().build().perform();
		
		WebElement info = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@title='Additional Details'])[1]")));
		
		builder.moveToElement(info).click().build().perform();
		
		WebElement mobile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='phone'])[1]")));
		System.out.println("Mobile Number: " + mobile.getText());
		
		driver.close();

	}

}
