
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class ColorOfNavBar {
	public static void main(String[] a) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		driver.get("https://demo.suiteondemand.com/");
				
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		WebElement navbar= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='toolbar']")));
		
		String navColor = navbar.getCssValue("color");
		System.out.println("Color of the Navbar : " + navColor);
		
		driver.close();
	}
}
