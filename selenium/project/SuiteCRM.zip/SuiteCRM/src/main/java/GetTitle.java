import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;


public class GetTitle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.suiteondemand.com/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		driver.quit();
		

	}

}
