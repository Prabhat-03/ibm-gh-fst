@Login
Feature: Testing the Login functionality
  Scenario: Complete functionality of User login
    Given user is on the login page
    When the user enters "will" and "will"
    Then get the confirmation text and the url will be "https://demo.suiteondemand.com/index.php?module=Home&action=Demo"