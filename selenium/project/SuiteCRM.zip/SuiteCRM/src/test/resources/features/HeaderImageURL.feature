@GetHeaderURL
Feature: Retrieving Header Image URL
  Scenario: Opening a webpage and checking header image url
    Given user is on the login page
    Then header image is retrieved