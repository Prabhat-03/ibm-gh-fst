@LeadPhoneNumber
Feature: Testing the retrieval of phone number from the table 
  Scenario: Retrieving phone number from records 
    Given user is on the login page
    When the user enters "will" and "will" and press submit button
    Then get the confirmation text and the url will be "https://demo.suiteondemand.com/index.php?module=Home&action=Demo"
    And click on the sales button
    And then clicks on the lead button
    And click on the i button
    Then user can retrieve the phone number