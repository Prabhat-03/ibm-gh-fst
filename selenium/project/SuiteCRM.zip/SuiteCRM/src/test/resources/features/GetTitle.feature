@GetTitle
Feature: Retrieving Title
  Scenario: Opening a webpage and checking Title using Selenium
    Given user is on the login page
    Then title is retrieved