import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.testng.Assert.*;
import java.time.Duration;
import org.testng.annotations.*;


public class LeadPhoneNumberTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test(priority = 0)
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://demo.suiteondemand.com/index.php?module=Home&action=Demo");
	}
	
	
	@Test(priority=1)
	public void phoneTest() {
		WebElement sales = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='grouptab_0']")));
		//sales.click();
//		System.out.println("entered sales");
		builder.moveToElement(sales).click().pause(2000).build().perform();
		
		WebElement leads = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='moduleTab_6_Leads']")));
	
		builder.moveToElement(leads).click().build().perform();
		
		WebElement info = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@title='Additional Details'])[1]")));
		
		builder.moveToElement(info).click().build().perform();
		
		WebElement mobile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='phone'])[1]")));
		assertEquals(mobile.getText(), "(692) 886-8659");
	}
	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}
}
