import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.testng.Assert.*;
import java.time.Duration;
import org.testng.annotations.*;

public class HeaderImageURLTest {
	WebDriver driver;
	WebDriverWait wait;
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test
	public void headerTest() {
		WebElement img = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='SuiteCRM']")));
		String f = img.getDomAttribute("src");
		//assertEquals(f, "themes/default/images/company_logo.png?v=GhbmyZQdM1L54aHzj248MA");
		assertNotNull(f);
	}
	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}
}
