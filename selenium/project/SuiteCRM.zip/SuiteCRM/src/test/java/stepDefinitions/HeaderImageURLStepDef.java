package stepDefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.*;

public class HeaderImageURLStepDef extends BaseClass {
	
	@Then("header image is retrieved")
	public void headerImage() throws Throwable{
		WebElement img = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@alt='SuiteCRM']")));
		String f = img.getDomAttribute("src");
		//assertEquals(f, "themes/default/images/company_logo.png?v=GhbmyZQdM1L54aHzj248MA");
		assertNotNull(f);
	}
	
}
