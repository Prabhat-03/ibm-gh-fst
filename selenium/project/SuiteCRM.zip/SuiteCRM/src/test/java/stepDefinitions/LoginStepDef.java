package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.*;

public class LoginStepDef extends BaseClass {
	
	@When("the user enters {string} and {string} and press submit button")
	public void login(String a, String b) {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys(a);
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys(b);
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
	
	}

	@Then("get the confirmation text and the url will be {string}")
	public void linkCheck(String c) {
		assertEquals(c, driver.getCurrentUrl());
	}
}
