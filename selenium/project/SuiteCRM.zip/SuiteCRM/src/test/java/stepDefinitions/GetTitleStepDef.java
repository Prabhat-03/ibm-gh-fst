package stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.*;

public class GetTitleStepDef extends BaseClass {
	@Given("user is on the login page")
	public void setup() {
		driver.get("https://demo.suiteondemand.com/");
	}

	@Then("title is retrieved")
	public void getTitle() {
		assertEquals(driver.getTitle(), "SuiteCRM Demo");
	}
}
