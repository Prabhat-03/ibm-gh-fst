package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.*;

public class LeadPhoneNumberStepDef extends BaseClass{
	@And("click on the sales button")
	public void clickOnSalesBtn() {
		WebElement sales = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='grouptab_0']")));
		//sales.click();
		builder.moveToElement(sales).click().pause(2000).build().perform();
	}

	@And("then clicks on the lead button")
	public void clickOnLeadBtn() {
		WebElement leads = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='moduleTab_6_Leads']")));
		builder.moveToElement(leads).click().build().perform();
	}
	
	@And("click on the i button")
	public void clickOnInfoButton() {
		WebElement info = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@title='Additional Details'])[1]")));	
		builder.moveToElement(info).click().build().perform();
	}
	
	@Then("user can retrieve the phone number")
	public void retrievePhoneNo() {
		WebElement mobile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='phone'])[1]")));
		assertEquals(mobile.getText(), "(520) 969-7513");
	}
}
