import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MenuCheckingTest {
	WebDriver driver;
	WebDriverWait wait;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test(priority = 0)
	public void menTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://demo.suiteondemand.com/index.php?module=Home&action=Demo");
	}
	
	
	@Test(priority=1)
	public void menuTest() {
		WebElement activities = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='grouptab_3']")));
		assertEquals(activities.getText(), "ACTIVITIES");
	}
	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}

}
