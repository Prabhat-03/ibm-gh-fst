import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TraversingTablesTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test(priority = 0)
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://demo.suiteondemand.com/index.php?module=Home&action=Demo");
	}
	
	
	@Test(priority=1)
	public void tablesTest() {
		WebElement sales = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='grouptab_0']")));
		//sales.click();
		builder.moveToElement(sales).click().pause(2000).build().perform();
		
		
		WebElement account = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id ='moduleTab_6_Accounts']")));
		builder.moveToElement(account).click().build().perform();
		
		List<WebElement> oddRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[@class='oddListRowS1']/td[@type='name']//a")));
		
		//assertEquals(oddRows.size(), 10);	

		List<String> top5Names = new ArrayList<>();

		for (int i = 0; i < Math.min(5, oddRows.size()); i++) {
			top5Names.add(oddRows.get(i).getText());
		}

		assertEquals(top5Names.size(), 5);

	}	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}
}
