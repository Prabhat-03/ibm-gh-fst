import static org.testng.Assert.assertEquals;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TraversingTablesSecondTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test(priority = 0)
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://demo.suiteondemand.com/index.php?module=Home&action=Demo");
	}
	
	
	@Test(priority=1)
	public void tablesTest() {
		WebElement sales = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='grouptab_0']")));
		//sales.click();

		builder.moveToElement(sales).click().pause(2000).build().perform();
		
		WebElement leads = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='moduleTab_6_Leads']")));
	
		builder.moveToElement(leads).click().build().perform();
		
		
		List<WebElement> top10Rows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr/td[3]//a")));
		List<WebElement> userRows = driver.findElements(By.xpath("//tr/td[8]//a"));
		
		System.out.println("Rows Size : " + top10Rows.size() + " The first Ten Names are: ");
		

		List<String> top10Names = new ArrayList<>();

		for (int i = 0; i < 10; i++) {
			top10Names.add(top10Rows.get(i).getText());
		}


		assertEquals(top10Names.size(), 10);

	}	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}
}
