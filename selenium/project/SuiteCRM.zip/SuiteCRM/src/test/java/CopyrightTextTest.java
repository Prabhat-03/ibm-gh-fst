import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.testng.Assert.*;
import java.time.Duration;
import org.testng.annotations.*;

public class CopyrightTextTest {
	WebDriver driver;
	WebDriverWait wait;
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test
	public void headerTest() {
		WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='admin_options']")));

		assertEquals(el.getText(), "© Supercharged by SuiteCRM");
	}
	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}

}
