import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.testng.Assert.*;
import java.time.Duration;
import org.testng.annotations.*;

public class LoginTest {
	WebDriver driver;
	WebDriverWait wait;
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		driver.get("https://demo.suiteondemand.com/");
		
	}
	
	@Test
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='user_name']")));
		user.sendKeys("will");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username_password']")));
		password.sendKeys("will");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Login']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://demo.suiteondemand.com/index.php?module=Home&action=Demo");
	}
	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}
}
