import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import static org.testng.Assert.*;
import org.testng.annotations.*;

public class GetTitleTest {
	WebDriver driver;
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		driver.get("https://demo.suiteondemand.com/");
	}
	
	@Test
	public void titleTest() {
		assertEquals(driver.getTitle(), "SuiteCRM Demo");
	}
	
	
	
	@AfterClass
	public void cleanup() {
		driver.quit();

	}
}