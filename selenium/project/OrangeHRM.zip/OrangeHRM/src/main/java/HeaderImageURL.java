import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class HeaderImageURL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://hrm.alchemy.hguy.co/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement img = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id = 'divLogo']/img")));
		System.out.println("Link of the Image: " + img.getDomAttribute("src"));
		
		driver.quit();
	}

}