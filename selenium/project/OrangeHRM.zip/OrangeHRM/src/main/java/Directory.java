import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Directory {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(45));
		Actions builder = new Actions(driver);
	
		driver.get("https://hrm.alchemy.hguy.co/");
	
		System.out.println("The Title of the page is: " + driver.getTitle());
	
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
	
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
	
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
	
		WebElement directory = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_directory_viewDirectory']")));
		builder.moveToElement(directory).click().pause(2000).build().perform();
		
		WebElement dirHeading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='head']//h1")));
		System.out.println("Directory Heading : "+ dirHeading.getText());
		
		driver.close();
	
	
	}
}
