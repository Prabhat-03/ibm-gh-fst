import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddingQualification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(45));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		WebElement myInfo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewMyDetails']")));
		builder.moveToElement(myInfo).click().pause(2000).build().perform();

		WebElement qual = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/symfony/web/index.php/pim/viewQualifications/empNumber/1']")));
		//builder.moveToElement(qual).click().build().perform();
		qual.click();
		
		WebElement add = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='addWorkExperience']")));
		add.click();
		
		WebElement company = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='experience_employer']")));
		company.clear();
		builder.moveToElement(company).click().sendKeys("Commiee.KM").build().perform();
		
		WebElement job = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='experience_jobtitle']")));
		job.clear();
		builder.moveToElement(job).click().sendKeys("Comrade").build().perform();
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='btnWorkExpSave']")));
		builder.moveToElement(saveBtn).click().build().perform();
		
		driver.close();
	}

}
