import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EditUserInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(45));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		WebElement myInfo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewMyDetails']")));
		builder.moveToElement(myInfo).click().pause(2000).build().perform();
	
		WebElement editBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnSave' ]")));
		builder.moveToElement(editBtn).click().build().perform();
		
		WebElement firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'personal_txtEmpFirstName' ]")));
		firstName.clear();
		builder.moveToElement(firstName).click().sendKeys("Yshesh").build().perform();
		
		WebElement lastName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'personal_txtEmpLastName' ]")));
		lastName.clear();
		builder.moveToElement(lastName).click().sendKeys("the Great").build().perform();
		
		WebElement gender = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='personal_optGender_2']")));
		builder.moveToElement(gender).click().build().perform();
		
		WebElement dropdownElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='personal_cmbNation']")));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Greek");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnSave' ]")));
		builder.moveToElement(saveBtn).click().build().perform();
		
		driver.close();
	
	}

}
