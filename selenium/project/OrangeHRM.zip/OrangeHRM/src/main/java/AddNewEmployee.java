import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddNewEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(45));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		WebElement PIM = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewPimModule']")));
		builder.moveToElement(PIM).click().pause(3000).build().perform();
		
		WebElement addEmp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnAdd']")));
		builder.moveToElement(addEmp).click().build().perform();
		
		WebElement firstName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id = 'firstName']")));
		builder.moveToElement(firstName).click().sendKeys("Yshesh").build().perform();
		
		WebElement lastName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id = 'lastName']")));
		builder.moveToElement(lastName).click().sendKeys("R K").build().perform();
		
		WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id = 'btnSave']")));
		builder.moveToElement(saveBtn).click().build().perform();
		
		WebElement empList = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id = 'menu_pim_viewEmployeeList']")));
		builder.moveToElement(empList).click().build().perform();
		
		WebElement fullName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id = 'empsearch_employee_name_empName']")));
		builder.moveToElement(fullName).click().sendKeys("Yshesh R K").build().perform();
		
		WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id = 'searchBtn']")));
		builder.moveToElement(searchBtn).click().build().perform();
		 
		
		driver.close();
	}

}
