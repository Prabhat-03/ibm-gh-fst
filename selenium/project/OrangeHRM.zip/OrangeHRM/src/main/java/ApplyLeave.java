import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ApplyLeave {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(45));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		
		System.out.println("The Title of the page is: " + driver.getTitle());
		
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		WebElement applyLeave = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Apply Leave']")));
		builder.moveToElement(applyLeave).click().pause(2000).build().perform();
		
		WebElement leaveType = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='applyleave_txtLeaveType']")));
		Select dropdown = new Select(leaveType);
		dropdown.selectByVisibleText("Holiday");
		
		WebElement fromDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyleave_txtFromDate']")));
//		builder.moveToElement(fromDate).click().sendKeys("2026-07-03").pause(2000).build().perform();
		fromDate.clear();
		fromDate.sendKeys("2026-07-03");
		
		WebElement toDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyleave_txtToDate']")));
//		builder.moveToElement(toDate).click().sendKeys("2026-07-04").pause(2000).build().perform();
		toDate.clear();
		toDate.sendKeys("2026-07-04");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyBtn']")));
//		builder.moveToElement(saveBtn).pause(2000).click().build().perform();
		saveBtn.click();
		
		WebElement applyLeave1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_leave_viewLeaveModule']")));
		builder.moveToElement(applyLeave1).click().pause(2000).build().perform();
		
		WebElement myLeave = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_leave_viewMyLeaveList']")));
		builder.moveToElement(myLeave).click().pause(2000).build().perform();
		
		WebElement leaveStatus = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[@class='odd'][1]/td[6]")));
		System.out.println("Leave Status : " + leaveStatus.getText());
		
		
		driver.close();
	}

}
