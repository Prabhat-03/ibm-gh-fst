import static org.testng.Assert.*;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AddingQualificationTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://hrm.alchemy.hguy.co/");
	}
	
	
	@Test(priority=0)
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://hrm.alchemy.hguy.co/symfony/web/index.php/dashboard");
	}
	
	
	@Test(priority=1)
	public void addingQualification() {
		WebElement myInfo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewMyDetails']")));
		builder.moveToElement(myInfo).click().pause(2000).build().perform();

		WebElement qual = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='sidenav']/li[9]")));
		qual.click();
		
		WebElement add = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='addWorkExperience']")));
		add.click();
		
		WebElement company = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='experience_employer']")));
		company.clear();
		company.sendKeys("Commiee");
		
		WebElement job = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='experience_jobtitle']")));
		job.clear();
		job.sendKeys("Comrade");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='btnWorkExpSave']")));
		saveBtn.click();
		
		List<WebElement> tableRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//table[@class='table hover']/tbody/tr")));
		System.out.println(tableRows.size());
		boolean found = false;
		for(WebElement t: tableRows) {
			builder.pause(1000).build().perform();
			String comp = t.findElement(By.xpath("//table[@class='table hover']/tbody/tr/td[@class='name']")).getText().trim();
			String jobTitle = t.findElement(By.xpath("//table[@class='table hover']/tbody/tr/td[3]")).getText().trim();
			if (comp.equals("Commiee") && jobTitle.equals("Comrade")) {
		        System.out.println(comp + jobTitle);
				found = true;
		        break;
		    }
		
		}
		assertTrue(found);
//		assertEquals(found, false);
	}
	
	
	@AfterClass
	public void cleanup() {
		driver.close();
	}
}
