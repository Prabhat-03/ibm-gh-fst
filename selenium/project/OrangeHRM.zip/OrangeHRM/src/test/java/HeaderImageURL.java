import static org.testng.Assert.*;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HeaderImageURL {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		builder = new Actions(driver);
		driver.get("https://hrm.alchemy.hguy.co/");
	}
	
	
	@Test(priority=0)
	public void headerTest() {
		WebElement img = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id = 'divLogo']/img")));
		System.out.println("Link of the Image: " + img.getDomAttribute("src"));
		
		assertEquals(img.getDomAttribute("src"), "/symfony/web/webres_618e67a57beec1.83834480/themes/default/images/login/logo.png");
	}
	
	@AfterClass
	public void cleanup() {
		driver.close();
	}
}
