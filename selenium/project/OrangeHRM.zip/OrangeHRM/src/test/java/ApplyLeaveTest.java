import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ApplyLeaveTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://hrm.alchemy.hguy.co/");
	}
	
	
	@Test(priority=0)
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		assertEquals(driver.getCurrentUrl(), "https://hrm.alchemy.hguy.co/symfony/web/index.php/dashboard");
	}
	
	
	@Test(priority=1)
	public void applyLeave() {
		WebElement applyLeave = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Apply Leave']")));
		builder.moveToElement(applyLeave).click().pause(2000).build().perform();
		
		WebElement leaveType = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='applyleave_txtLeaveType']")));
		Select dropdown = new Select(leaveType);
		dropdown.selectByVisibleText("Holiday");
		
		WebElement fromDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyleave_txtFromDate']")));
		fromDate.clear();
		fromDate.sendKeys("2026-07-03");
		
		WebElement toDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyleave_txtToDate']")));
		toDate.clear();
		toDate.sendKeys("2026-07-04");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyBtn']")));
		saveBtn.click();
		
		WebElement applyLeave1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_leave_viewLeaveModule']")));
		builder.moveToElement(applyLeave1).click().pause(2000).build().perform();
		
		WebElement myLeave = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_leave_viewMyLeaveList']")));
		builder.moveToElement(myLeave).click().pause(2000).build().perform();
		
		WebElement leaveStatus = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[@class='odd'][1]/td[6]")));
		String Status = leaveStatus.getText();
		
		if(Status.contains("Pending Approval")) 
			assertEquals(Status.contains("Pending Approval"), true);
		else
			assertEquals(Status.contains("Cancelled"), true);
		
	}
	
	@AfterClass
	public void cleanup() {
		driver.close();
	}
}
