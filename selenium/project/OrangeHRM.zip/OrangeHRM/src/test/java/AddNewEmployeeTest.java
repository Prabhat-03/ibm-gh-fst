import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AddNewEmployeeTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		builder = new Actions(driver);
		driver.get("https://hrm.alchemy.hguy.co/");
	}
	
	
	@Test(priority=0)
	public void loginTest() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
		
		Assert.assertEquals(driver.getCurrentUrl(), "https://hrm.alchemy.hguy.co/symfony/web/index.php/dashboard");
	}
	
	
	@Test(priority=1)
	public void newEmployeeCheck() {		
		WebElement PIM = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewPimModule']")));
		PIM.click();
		
		WebElement addEmp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_addEmployee']")));
		addEmp.click();
		
		WebElement firstName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='firstName']")));
		firstName.click();
		firstName.sendKeys("Nurendar");
		
		WebElement lastName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='lastName']")));
		lastName.click();
		lastName.sendKeys("Moody");
		
		WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='btnSave']")));
		saveBtn.click();
		
		WebElement empList = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='menu_pim_viewEmployeeList']")));
		empList.click();
		
		builder.pause(3000).build().perform();
		WebElement fullName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='empsearch_employee_name_empName']")));
		fullName.clear();
		fullName.click();
		fullName.sendKeys("Nurendar Moody");
		fullName.sendKeys(Keys.ENTER);

		builder.pause(3000).build().perform();
		WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("searchBtn")));
		searchBtn.click();
		
		builder.pause(3000).build().perform();
		boolean found = false;
		List<WebElement> nameCheck =  wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//table[@id='resultTable']/tbody/tr/td[3]/a")));

		for(WebElement n: nameCheck) {
			String name = n.getText();
			
			if (name.equals("Nurendar")) {
				found = true;
				break;
			}
		}
		
		assertTrue(found);
	
	}
	
	@AfterClass
	public void cleanup() {
		driver.close();
	}
}
