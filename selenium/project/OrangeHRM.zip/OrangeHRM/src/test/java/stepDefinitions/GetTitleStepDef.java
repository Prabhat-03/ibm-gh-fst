package stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.*;

public class GetTitleStepDef extends BaseClass {
	@Given("user opens the browser")
	public void setup() {
		driver.get("https://hrm.alchemy.hguy.co/");

	}
	
	@Then("title is displayed")
	public void getTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}
}
