package stepDefinitions;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.*;

public class AddNewEmployeeStepDef extends BaseClass{
	@Then("finds the PIM option")
	public void pimSection() {
		WebElement PIM = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewPimModule']")));
		PIM.click();
	}
	
	@Then("clicks the add Employee button")
	public void addEmployee() {
		WebElement addEmp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_addEmployee']")));
		addEmp.click();
	}
	
	@Then("fill details and click Save")
	public void fillDetails() {
		WebElement firstName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='firstName']")));
		firstName.click();
		firstName.sendKeys("Nurendar");
		
		WebElement lastName = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='lastName']")));
		lastName.click();
		lastName.sendKeys("Moody");
		
		WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='btnSave']")));
		saveBtn.click();
	}
	
	
	@Then("Navigate back and verify Employee")
	public void verifyEmployee() {
		WebElement empList = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='menu_pim_viewEmployeeList']")));
		empList.click();
		
		builder.pause(3000).build().perform();
		WebElement fullName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='empsearch_employee_name_empName']")));
		fullName.clear();
		fullName.click();
		fullName.sendKeys("Nurendar Moody");
		fullName.sendKeys(Keys.ENTER);

		builder.pause(3000).build().perform();
		WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("searchBtn")));
		searchBtn.click();
		
		builder.pause(3000).build().perform();
		boolean found = false;
		List<WebElement> nameCheck =  wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//table[@id='resultTable']/tbody/tr/td[3]/a")));

		for(WebElement n: nameCheck) {
			String name = n.getText();
			
			if (name.equals("Nurendar")) {
				found = true;
				break;
			}
		}
		
		assertTrue(found);
	}
	
}
