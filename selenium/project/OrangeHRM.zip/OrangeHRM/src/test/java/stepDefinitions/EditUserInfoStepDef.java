package stepDefinitions;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.*;

public class EditUserInfoStepDef extends BaseClass {
	@Then("finds the MyInfo option")
	public void myInfo() {
		WebElement myInfo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_pim_viewMyDetails']")));
		builder.moveToElement(myInfo).click().pause(2000).build().perform();
	}
	
	@Then("clicks the Edit button")
	public void editInfo() {
		WebElement editBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnSave' ]")));
		builder.moveToElement(editBtn).click().build().perform();
	}
	
	@Then("fill Name, Gender and DOB and click Save")
	public void fillDetails() {
		WebElement firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'personal_txtEmpFirstName' ]")));
		firstName.clear();
		builder.moveToElement(firstName).click().sendKeys("Yshesh").build().perform();
		
		WebElement lastName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'personal_txtEmpLastName' ]")));
		lastName.clear();
		builder.moveToElement(lastName).click().sendKeys("the Great").build().perform();
		
		WebElement gender = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='personal_optGender_2']")));
		builder.moveToElement(gender).click().build().perform();
		
		WebElement dropdownElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='personal_cmbNation']")));
		Select dropdown = new Select(dropdownElement);
		dropdown.selectByVisibleText("Greek");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnSave' ]")));
		builder.moveToElement(saveBtn).click().build().perform();
		
		WebElement firstNameCheck = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value = 'Yshesh']")));
		WebElement lastNameCheck = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='the Great']")));
		
		
		assertTrue(firstNameCheck.isDisplayed());
		assertTrue(lastNameCheck.isDisplayed());
	}

}
