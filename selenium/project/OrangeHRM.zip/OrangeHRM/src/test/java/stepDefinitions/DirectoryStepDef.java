package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.*;

public class DirectoryStepDef extends BaseClass{
	@Then("finds the Directory option")
	public void directorySection() {
		WebElement directory = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_directory_viewDirectory']")));
		builder.moveToElement(directory).click().pause(2000).build().perform();
	}
	
	@Then("verifies the Directory Heading")
	public void verifyDirectoryHeading() {
		WebElement dirHeading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='head']//h1")));
		
		assertEquals(dirHeading.getText(), "Search Directory");
	}
}
