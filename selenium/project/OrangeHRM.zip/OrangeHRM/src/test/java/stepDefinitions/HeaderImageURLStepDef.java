package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.*;

public class HeaderImageURLStepDef extends BaseClass{
	@Then("url of header is displayed")
	public void getImageURL() {
		WebElement img = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id = 'divLogo']/img")));
		System.out.println("Link of the Image: " + img.getDomAttribute("src"));
		
		assertEquals(img.getDomAttribute("src"), "/symfony/web/webres_618e67a57beec1.83834480/themes/default/images/login/logo.png");
	}

}
