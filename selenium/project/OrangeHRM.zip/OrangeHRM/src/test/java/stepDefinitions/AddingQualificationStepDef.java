package stepDefinitions;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;

public class AddingQualificationStepDef extends BaseClass{
	@Then("finds the Qualifications option")
	public void qualificationSection() {
		WebElement qual = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='sidenav']/li[9]")));
		qual.click();
	}
	
	@Then("add Work Experience and clicks Save")
	public void addExperience() {
		WebElement add = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='addWorkExperience']")));
		add.click();
		
		WebElement company = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='experience_employer']")));
		company.clear();
		company.sendKeys("Commiee");
		
		WebElement job = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='experience_jobtitle']")));
		job.clear();
		job.sendKeys("Comrade");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='btnWorkExpSave']")));
		saveBtn.click();
		
		List<WebElement> tableRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//table[@class='table hover']/tbody/tr")));
		System.out.println(tableRows.size());
		boolean found = false;
		for(WebElement t: tableRows) {
			builder.pause(1000).build().perform();
			String comp = t.findElement(By.xpath("//table[@class='table hover']/tbody/tr/td[@class='name']")).getText().trim();
			String jobTitle = t.findElement(By.xpath("//table[@class='table hover']/tbody/tr/td[3]")).getText().trim();
			if (comp.equals("Commiee") && jobTitle.equals("Comrade")) {
		        System.out.println(comp + jobTitle);
				found = true;
		        break;
		    }
		
		}
		assertTrue(found);
	}
}
