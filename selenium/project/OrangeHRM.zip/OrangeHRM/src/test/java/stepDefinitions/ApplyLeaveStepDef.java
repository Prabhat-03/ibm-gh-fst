package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Then;

public class ApplyLeaveStepDef extends BaseClass {
	@Then("finds the Apply Leave option")
	public void applyLeaveSection() {
		WebElement applyLeave = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Apply Leave']")));
		builder.moveToElement(applyLeave).click().pause(2000).build().perform();
	}
	
	@Then("Select the leave type and duration of leave")
	public void selectLeaveTypeDuration() {
		WebElement leaveType = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='applyleave_txtLeaveType']")));
		Select dropdown = new Select(leaveType);
		dropdown.selectByVisibleText("Holiday");
		
		WebElement fromDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyleave_txtFromDate']")));
		fromDate.clear();
		fromDate.sendKeys("2026-07-03");
		
		WebElement toDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyleave_txtToDate']")));
		toDate.clear();
		toDate.sendKeys("2026-07-04");
		
		WebElement saveBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='applyBtn']")));
		saveBtn.click();
	}
	
	@Then("navigate back to verify status of leave")
	public void verifyLeaveStatus() {
		WebElement applyLeave1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_leave_viewLeaveModule']")));
		builder.moveToElement(applyLeave1).click().pause(2000).build().perform();
		
		WebElement myLeave = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='menu_leave_viewMyLeaveList']")));
		builder.moveToElement(myLeave).click().pause(2000).build().perform();
		
		WebElement leaveStatus = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[@class='odd'][1]/td[6]")));
		String Status = leaveStatus.getText();
		
		if(Status.contains("Pending Approval")) 
			assertEquals(Status.contains("Pending Approval"), true);
		else
			assertEquals(Status.contains("Cancelled"), true);
	}

}
