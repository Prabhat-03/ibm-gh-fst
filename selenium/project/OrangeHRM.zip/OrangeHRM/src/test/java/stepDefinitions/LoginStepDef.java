package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import io.cucumber.java.en.*;

public class LoginStepDef extends BaseClass{
	@When("user logins")
	public void userLogin() {
		WebElement user = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtUsername']")));
		user.sendKeys("orange");
		
		WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'txtPassword']")));
		password.sendKeys("5Nx#I6BK%r3$8vz0ch");
		
		WebElement login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id = 'btnLogin']")));
		login.click();
	}
	
	@Then("homepage url is displayed")
	public void homepageURL() {
		Assert.assertEquals(driver.getCurrentUrl(), "https://hrm.alchemy.hguy.co/symfony/web/index.php/dashboard");
	}
}
