package stepDefinitions;

import static org.testng.Assert.assertNotNull;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;

public class EmergencyContactStepDef extends BaseClass{
	@Then("finds the Emergency Contacts option")
	public void findEmergencySection() {
		WebElement eContacts = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Emergency Contacts']")));
		eContacts.click();
	}
	
	
	@Then("retrieve and print information")
	public void retrieveInfo() {
		List<WebElement> contacts = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//table[@id='emgcontact_list']")));
		
		for(WebElement c: contacts) {
			System.out.println(c.getText());
		}
		
		
		assertNotNull(contacts);
	}
}
