import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GetTitleTest {
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	
	
	@BeforeClass
	public void createInstance() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		builder = new Actions(driver);
		driver.get("https://hrm.alchemy.hguy.co/");
	}
	
	
	@Test(priority=0)
	public void titleTest() {
		
		assertEquals(driver.getTitle(), "OrangeHRM");
	}
	
	@AfterClass
	public void cleanup() {
		driver.close();
	}
}
