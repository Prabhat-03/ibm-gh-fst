@activity3
Feature: Logging into site
	Scenario:
		Given user opens the browser
		When user logins
		Then homepage url is displayed