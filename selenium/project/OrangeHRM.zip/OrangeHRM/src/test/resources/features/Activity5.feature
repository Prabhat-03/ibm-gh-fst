@activity5
Feature: Edit User Information
	Scenario:
		Given user opens the browser
		When user logins
		Then finds the MyInfo option
		Then clicks the Edit button
		Then fill Name, Gender and DOB and click Save
		