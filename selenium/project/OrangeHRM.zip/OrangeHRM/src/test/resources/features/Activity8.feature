@activity8
Feature: Apply for Leave
	Scenario:
		Given user opens the browser
		When user logins
		Then finds the Apply Leave option
		Then Select the leave type and duration of leave
		Then navigate back to verify status of leave