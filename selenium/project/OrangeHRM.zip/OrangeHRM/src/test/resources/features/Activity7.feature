@activity7
Feature: Add Employee Qualifications
	Scenario:
		Given user opens the browser
		When user logins
		Then finds the MyInfo option
		Then finds the Qualifications option
		Then add Work Experience and clicks Save