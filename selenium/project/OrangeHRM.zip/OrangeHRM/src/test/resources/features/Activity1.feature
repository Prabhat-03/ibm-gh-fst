@activity1
Feature: Verify the website title
	Scenario:
		Given user opens the browser
		Then title is displayed