@activity6
Feature: Verify directory is visible
	Scenario:
		Given user opens the browser
		When user logins
		Then finds the Directory option
		Then verifies the Directory Heading