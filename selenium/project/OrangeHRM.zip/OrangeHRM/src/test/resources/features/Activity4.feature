@activity4
Feature: Adding a new Employee
	Scenario:
		Given user opens the browser
		When user logins
		Then finds the PIM option
		Then clicks the add Employee button
		Then fill details and click Save
		Then Navigate back and verify Employee
		