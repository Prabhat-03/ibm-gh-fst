@activity9
Feature: Retrieve Emergency Contacts
	Scenario:
		Given user opens the browser
		When user logins
		Then finds the MyInfo option
		Then finds the Emergency Contacts option
		Then retrieve and print information