@activity2
Feature: Get Url of Header Image
	Scenario:
		Given user opens the browser
		Then url of header is displayed